% Write a prolog program to calculate the sum of two numbers

sum(X, Y, Sum) :-
    Sum is X + Y.

%?- sum(5, 7, Result).
