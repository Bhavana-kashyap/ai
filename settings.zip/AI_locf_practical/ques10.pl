% Write a Prolog program to implement reverse (L, R) where List L is original and List
% R is reversed list.

reverse([], []).
reverse([H|T], R) :-
    reverse(T, RevT),
    conc(RevT, [H], R).

% ?- reverse([1, 2, 3, 4], Result).
