% Write a program in PROLOG to implement palindrome (L) which checks whether a
% list L is a palindrome or not

reverse([], []).
reverse([X|Xs], Rev) :-
    reverse(Xs, RevXs),
    append(RevXs, [X], Rev).

palindrome(L) :-
    reverse(L, RevL),
    L = RevL.

% ?- palindrome([1, 2, 3, 2, 1]).
