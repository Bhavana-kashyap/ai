% Write a Prolog program to implement maxlist(L, M) so that M is the maximum
% number in the list.

maxlist([X], X).
maxlist([H|T], Max) :-
    maxlist(T, MaxTail),
    (H > MaxTail -> Max = H ; Max = MaxTail).

% ?- maxlist([1, 6, 3, 8, 2], Result).
