% Write a prolog program to implement insert_nth (I, N, L, R) that inserts an item I into
% Nth position of list L to generate a list R.

insert_nth(Item, 1, List, [Item|List]).
insert_nth(Item, N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    insert_nth(Item, N1, T, R).


% ?- insert_nth(99, 3, [1, 2, 3, 4, 5], Result).
